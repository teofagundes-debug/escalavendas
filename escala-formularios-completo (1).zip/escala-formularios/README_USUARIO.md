# Sistema de Diagnóstico e ROI - Escala Vendas

## Sobre o Sistema

Este é um sistema web desenvolvido em React para gerenciar o processo de diagnóstico e análise de ROI da **Metodologia Escala de Implantação Inteligente**. O sistema permite coletar informações de forma estruturada e automaticamente propagar os dados entre as diferentes fases do processo.

## Características Principais

### ✅ Preenchimento Automático
- Os dados coletados no **Diagnóstico Inicial** são automaticamente propagados para os formulários subsequentes
- Informações como nome da empresa, responsável, métricas iniciais são reutilizadas nas próximas fases
- Reduz retrabalho e garante consistência dos dados

### ✅ Navegação Intuitiva
- Barra de progresso visual mostrando as 3 fases do processo
- Navegação sequencial com botões "Próximo" e "Voltar"
- Indicadores visuais de fase concluída

### ✅ Exportação de Dados
- Cada fase possui botão para exportar os dados em formato JSON
- Ao final, é possível gerar um relatório completo com todos os dados coletados
- Facilita backup e integração com outros sistemas

### ✅ Cálculos Automáticos
- Variações percentuais calculadas automaticamente (Antes x Depois)
- ROI calculado com base nos dados de investimento e economia
- Payback calculado automaticamente

## Estrutura das Fases

### Fase 1: Diagnóstico Inicial
Coleta informações essenciais sobre:
- Informações gerais da empresa
- Equipe de atendimento
- Canais de atendimento
- Custos envolvidos
- Objetivos e metas
- Principais desafios

### Fase 2: Matriz de ROI
Analisa oportunidades com base no diagnóstico:
- Pontos de atrito identificados
- Oportunidades de ganho
- Matriz detalhada de oportunidades com potencial de ROI
- Estimativas de redução de custos e aumento de receita

### Fase 3: Relatório de ROI Pós-Implantação
Compara resultados antes e depois:
- Dados comparativos (volume, TMR, TMA)
- Ganhos de produtividade
- Cálculo de ROI e Payback
- Feedback do cliente
- Recomendações para otimização

## Como Usar

### Instalação e Execução Local

1. **Pré-requisitos**
   - Node.js 18+ instalado
   - pnpm instalado (ou npm/yarn)

2. **Instalar dependências**
   ```bash
   cd escala-formularios
   pnpm install
   ```

3. **Executar em modo de desenvolvimento**
   ```bash
   pnpm run dev
   ```
   A aplicação estará disponível em `http://localhost:5173`

4. **Build para produção**
   ```bash
   pnpm run build
   ```
   Os arquivos otimizados estarão na pasta `dist/`

### Deploy em Serviço de Hospedagem

#### Opção 1: Vercel (Recomendado)
1. Crie uma conta em [vercel.com](https://vercel.com)
2. Instale o Vercel CLI: `npm i -g vercel`
3. Na pasta do projeto, execute: `vercel`
4. Siga as instruções para fazer o deploy

#### Opção 2: Netlify
1. Crie uma conta em [netlify.com](https://netlify.com)
2. Arraste a pasta `dist/` (após fazer o build) para o Netlify Drop
3. Ou conecte seu repositório Git para deploy automático

#### Opção 3: GitHub Pages
1. Adicione no `package.json`:
   ```json
   "homepage": "https://seuusuario.github.io/escala-formularios"
   ```
2. Instale: `npm install --save-dev gh-pages`
3. Adicione scripts:
   ```json
   "predeploy": "pnpm run build",
   "deploy": "gh-pages -d dist"
   ```
4. Execute: `pnpm run deploy`

## Personalização

### Cores e Identidade Visual
As cores da Escala Vendas já estão configuradas no arquivo `src/App.css`:
- Verde principal: `#00D9A3`
- Verde secundário: `#00B88F`
- Preto: `#1a1a1a`

Para alterar, edite as variáveis CSS no arquivo `src/App.css`.

### Adicionar Novos Campos
1. Abra o componente correspondente em `src/components/`
2. Adicione o campo no estado `formData`
3. Adicione o campo no JSX do formulário
4. O preenchimento automático já funcionará

### Modificar Cálculos
Os cálculos de ROI e Payback estão no componente `RelatorioROI.jsx`:
- Função `calcularROI()` - linha ~30
- Função `calcularPayback()` - linha ~40

## Tecnologias Utilizadas

- **React 18** - Framework JavaScript
- **Vite** - Build tool e dev server
- **Tailwind CSS** - Framework CSS
- **shadcn/ui** - Componentes de UI
- **Lucide React** - Ícones

## Estrutura de Arquivos

```
escala-formularios/
├── src/
│   ├── components/
│   │   ├── DiagnosticoForm.jsx    # Formulário de diagnóstico
│   │   ├── MatrizROI.jsx          # Formulário de matriz de ROI
│   │   └── RelatorioROI.jsx       # Formulário de relatório de ROI
│   ├── App.jsx                    # Componente principal
│   ├── App.css                    # Estilos personalizados
│   └── main.jsx                   # Ponto de entrada
├── index.html                     # HTML base
├── package.json                   # Dependências
└── vite.config.js                 # Configuração do Vite
```

## Suporte

Para dúvidas ou suporte técnico sobre a aplicação, entre em contato com o desenvolvedor.

Para informações sobre a metodologia e consultoria, entre em contato com:
- **Escala Vendas**
- E-mail: contato@escalavendas.com.br
- Endereço: R. Marechal Deodoro 450, Sala 304, Centro - Curitiba/PR

---

**Desenvolvido para Escala Vendas - Impulsionador Estratégico de Vendas**
