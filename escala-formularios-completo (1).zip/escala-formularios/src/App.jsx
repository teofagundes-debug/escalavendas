import { useState } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card } from '@/components/ui/card.jsx'
import { Progress } from '@/components/ui/progress.jsx'
import { FileText, TrendingUp, BarChart3, CheckCircle2 } from 'lucide-react'
import DiagnosticoForm from './components/DiagnosticoForm'
import MatrizROI from './components/MatrizROI'
import RelatorioROI from './components/RelatorioROI'
import './App.css'

function App() {
  const [currentStep, setCurrentStep] = useState(1)
  const [formData, setFormData] = useState({
    // Dados do diagnóstico inicial
    nomeEmpresa: '',
    responsavelAtendimento: '',
    cargo: '',
    email: '',
    telefone: '',
    dataDiagnostico: '',
    quantidadeAtendentes: '',
    turnosAtendimento: '',
    processosAtendimento: '',
    canais: [],
    volumeAtendimentos: '',
    tempoMedioAtendimento: '',
    tempoPrimeiraResposta: '',
    custoFolha: '',
    custoFerramentas: '',
    custoPerdas: '',
    objetivoPrincipal: '',
    metasQuantitativas: '',
    desafios: '',
    pontosAtrito: '',
    observacoes: '',
    // Dados da matriz de ROI
    pontosAtritoMatriz: '',
    oportunidadesGanho: '',
    oportunidades: [],
    // Dados do relatório de ROI
    periodoAnalise: '',
    dataRelatorio: '',
    metricas: {},
    feedback: '',
    pontosPositivos: '',
    pontosMelhorar: '',
    recomendacoes: ''
  })

  const steps = [
    { id: 1, name: 'Diagnóstico Inicial', icon: FileText },
    { id: 2, name: 'Matriz de ROI', icon: TrendingUp },
    { id: 3, name: 'Relatório de ROI', icon: BarChart3 }
  ]

  const progress = (currentStep / steps.length) * 100

  const handleNext = (data) => {
    setFormData({ ...formData, ...data })
    if (currentStep < steps.length) {
      setCurrentStep(currentStep + 1)
    }
  }

  const handlePrevious = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1)
    }
  }

  const handleExport = (type) => {
    // Função para exportar os dados
    const dataStr = JSON.stringify(formData, null, 2)
    const dataBlob = new Blob([dataStr], { type: 'application/json' })
    const url = URL.createObjectURL(dataBlob)
    const link = document.createElement('a')
    link.href = url
    link.download = `${type}_${formData.nomeEmpresa || 'dados'}.json`
    link.click()
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#00D9A3]/10 to-[#00B88F]/5">
      {/* Header */}
      <header className="bg-gradient-to-r from-[#00D9A3] to-[#00B88F] text-white py-8 px-4 shadow-lg">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-4xl font-bold mb-2">Escala Vendas</h1>
          <p className="text-lg opacity-90">Sistema de Diagnóstico e ROI - Metodologia de Implantação Inteligente</p>
        </div>
      </header>

      {/* Progress Bar */}
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <div className="flex justify-between items-center mb-4">
            {steps.map((step) => (
              <div key={step.id} className="flex flex-col items-center flex-1">
                <div className={`flex items-center justify-center w-12 h-12 rounded-full mb-2 transition-all ${
                  currentStep >= step.id 
                    ? 'bg-[#00D9A3] text-white' 
                    : 'bg-gray-200 text-gray-500'
                }`}>
                  {currentStep > step.id ? (
                    <CheckCircle2 className="w-6 h-6" />
                  ) : (
                    <step.icon className="w-6 h-6" />
                  )}
                </div>
                <span className={`text-sm font-medium text-center ${
                  currentStep >= step.id ? 'text-[#00D9A3]' : 'text-gray-500'
                }`}>
                  {step.name}
                </span>
              </div>
            ))}
          </div>
          <Progress value={progress} className="h-2" />
        </div>

        {/* Form Content */}
        <div className="bg-white rounded-lg shadow-md p-8">
          {currentStep === 1 && (
            <DiagnosticoForm 
              data={formData} 
              onNext={handleNext}
              onExport={() => handleExport('diagnostico')}
            />
          )}
          {currentStep === 2 && (
            <MatrizROI 
              data={formData} 
              onNext={handleNext}
              onPrevious={handlePrevious}
              onExport={() => handleExport('matriz_roi')}
            />
          )}
          {currentStep === 3 && (
            <RelatorioROI 
              data={formData} 
              onPrevious={handlePrevious}
              onExport={() => handleExport('relatorio_roi')}
            />
          )}
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-[#1a1a1a] text-white py-6 px-4 mt-12">
        <div className="max-w-7xl mx-auto text-center">
          <p className="font-semibold mb-1">Escala Vendas - Impulsionador Estratégico de Vendas</p>
          <p className="text-sm opacity-80">R. Marechal Deodoro 450, Sala 304, Centro - Curitiba/PR</p>
          <p className="text-sm opacity-80">E-mail: contato@escalavendas.com.br</p>
        </div>
      </footer>
    </div>
  )
}

export default App
