import { useState } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Textarea } from '@/components/ui/textarea.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { ArrowLeft, Download, CheckCircle2, FileDown } from 'lucide-react'

export default function RelatorioROI({ data, onPrevious, onExport }) {
  const [formData, setFormData] = useState({
    ...data,
    periodoAnalise: data.periodoAnalise || '',
    dataRelatorio: data.dataRelatorio || new Date().toISOString().split('T')[0],
    volumeAtendimentosAntes: data.volumeAtendimentos || '',
    volumeAtendimentosDepois: '',
    volumeAtendimentosIA: '',
    tmrAntes: data.tempoPrimeiraResposta || '',
    tmrDepois: '',
    tmaAntes: data.tempoMedioAtendimento || '',
    tmaDepois: '',
    atendimentosAutomatizados: '',
    horasEconomizadas: '',
    economiaCargaTrabalho: '',
    economiaProcessos: '',
    aumentoReceita: '',
    investimentoInicial: '',
    feedback: '',
    pontosPositivos: '',
    pontosMelhorar: '',
    recomendacoes: ''
  })

  const handleChange = (field, value) => {
    setFormData({ ...formData, [field]: value })
  }

  const calcularVariacao = (antes, depois) => {
    if (!antes || !depois) return '0'
    const variacao = ((parseFloat(depois) - parseFloat(antes)) / parseFloat(antes)) * 100
    return variacao.toFixed(1)
  }

  const calcularROI = () => {
    const investimento = parseFloat(formData.investimentoInicial) || 0
    const economia = parseFloat(formData.economiaCargaTrabalho || 0) + 
                     parseFloat(formData.economiaProcessos || 0) + 
                     parseFloat(formData.aumentoReceita || 0)
    
    if (investimento === 0) return '0'
    return (((economia - investimento) / investimento) * 100).toFixed(1)
  }

  const calcularPayback = () => {
    const investimento = parseFloat(formData.investimentoInicial) || 0
    const economiaMensal = parseFloat(formData.economiaCargaTrabalho || 0) + 
                           parseFloat(formData.economiaProcessos || 0) + 
                           parseFloat(formData.aumentoReceita || 0)
    
    if (economiaMensal === 0) return '0'
    return (investimento / economiaMensal).toFixed(1)
  }

  const handleGenerateReport = () => {
    const report = {
      ...formData,
      roiCalculado: calcularROI(),
      paybackCalculado: calcularPayback(),
      variacoes: {
        volumeAtendimentos: calcularVariacao(formData.volumeAtendimentosAntes, formData.volumeAtendimentosDepois),
        tmr: calcularVariacao(formData.tmrAntes, formData.tmrDepois),
        tma: calcularVariacao(formData.tmaAntes, formData.tmaDepois)
      }
    }
    
    const dataStr = JSON.stringify(report, null, 2)
    const dataBlob = new Blob([dataStr], { type: 'application/json' })
    const url = URL.createObjectURL(dataBlob)
    const link = document.createElement('a')
    link.href = url
    link.download = `relatorio_roi_${data.nomeEmpresa || 'completo'}.json`
    link.click()
  }

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-3xl font-bold text-[#00D9A3]">Relatório de ROI Pós-Implantação</h2>
          <p className="text-gray-600 mt-2">Fase 3: Análise de Resultados</p>
        </div>
        <Button type="button" variant="outline" onClick={onExport} className="flex items-center gap-2">
          <Download className="w-4 h-4" />
          Exportar Dados
        </Button>
      </div>

      {/* Informações Automáticas */}
      <Card className="border-l-4 border-l-[#00D9A3] bg-[#00D9A3]/5">
        <CardHeader>
          <CardTitle>Informações do Cliente</CardTitle>
          <CardDescription>Dados coletados nas fases anteriores</CardDescription>
        </CardHeader>
        <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <p className="text-sm font-medium text-gray-600">Empresa</p>
            <p className="text-lg font-semibold">{data.nomeEmpresa || 'Não informado'}</p>
          </div>
          <div>
            <p className="text-sm font-medium text-gray-600">Responsável</p>
            <p className="text-lg font-semibold">{data.responsavelAtendimento || 'Não informado'}</p>
          </div>
          <div>
            <p className="text-sm font-medium text-gray-600">Objetivo Principal</p>
            <p className="text-lg font-semibold">{data.objetivoPrincipal || 'Não informado'}</p>
          </div>
        </CardContent>
      </Card>

      {/* Informações Gerais */}
      <Card>
        <CardHeader>
          <CardTitle>Informações Gerais do Relatório</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="periodoAnalise">Período de Análise</Label>
              <Input
                id="periodoAnalise"
                value={formData.periodoAnalise}
                onChange={(e) => handleChange('periodoAnalise', e.target.value)}
                placeholder="Ex: 01/01/2025 a 31/01/2025"
              />
            </div>
            <div>
              <Label htmlFor="dataRelatorio">Data do Relatório</Label>
              <Input
                id="dataRelatorio"
                type="date"
                value={formData.dataRelatorio}
                onChange={(e) => handleChange('dataRelatorio', e.target.value)}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Dados Comparativos */}
      <Card>
        <CardHeader>
          <CardTitle>Dados Comparativos (Antes x Depois)</CardTitle>
          <CardDescription>Compare as métricas antes e após a implementação</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <Label>Volume de Atendimentos (Antes)</Label>
              <Input
                type="number"
                value={formData.volumeAtendimentosAntes}
                onChange={(e) => handleChange('volumeAtendimentosAntes', e.target.value)}
                placeholder="0"
              />
            </div>
            <div>
              <Label>Volume de Atendimentos (Depois)</Label>
              <Input
                type="number"
                value={formData.volumeAtendimentosDepois}
                onChange={(e) => handleChange('volumeAtendimentosDepois', e.target.value)}
                placeholder="0"
              />
            </div>
            <div>
              <Label>Variação</Label>
              <div className="h-10 flex items-center px-3 bg-gray-100 rounded-md font-semibold text-[#00D9A3]">
                {calcularVariacao(formData.volumeAtendimentosAntes, formData.volumeAtendimentosDepois)}%
              </div>
            </div>
          </div>

          <div>
            <Label>Volume Tratado pela IA</Label>
            <Input
              type="number"
              value={formData.volumeAtendimentosIA}
              onChange={(e) => handleChange('volumeAtendimentosIA', e.target.value)}
              placeholder="0"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <Label>TMR - Antes (minutos)</Label>
              <Input
                type="number"
                value={formData.tmrAntes}
                onChange={(e) => handleChange('tmrAntes', e.target.value)}
                placeholder="0"
              />
            </div>
            <div>
              <Label>TMR - Depois (minutos)</Label>
              <Input
                type="number"
                value={formData.tmrDepois}
                onChange={(e) => handleChange('tmrDepois', e.target.value)}
                placeholder="0"
              />
            </div>
            <div>
              <Label>Variação</Label>
              <div className="h-10 flex items-center px-3 bg-gray-100 rounded-md font-semibold text-[#00D9A3]">
                {calcularVariacao(formData.tmrAntes, formData.tmrDepois)}%
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <Label>TMA - Antes (minutos)</Label>
              <Input
                type="number"
                value={formData.tmaAntes}
                onChange={(e) => handleChange('tmaAntes', e.target.value)}
                placeholder="0"
              />
            </div>
            <div>
              <Label>TMA - Depois (minutos)</Label>
              <Input
                type="number"
                value={formData.tmaDepois}
                onChange={(e) => handleChange('tmaDepois', e.target.value)}
                placeholder="0"
              />
            </div>
            <div>
              <Label>Variação</Label>
              <div className="h-10 flex items-center px-3 bg-gray-100 rounded-md font-semibold text-[#00D9A3]">
                {calcularVariacao(formData.tmaAntes, formData.tmaDepois)}%
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Ganhos de Produtividade */}
      <Card>
        <CardHeader>
          <CardTitle>Ganhos de Produtividade e Redução de Custos</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="atendimentosAutomatizados">Atendimentos Automatizados (mês)</Label>
              <Input
                id="atendimentosAutomatizados"
                type="number"
                value={formData.atendimentosAutomatizados}
                onChange={(e) => handleChange('atendimentosAutomatizados', e.target.value)}
                placeholder="0"
              />
            </div>
            <div>
              <Label htmlFor="horasEconomizadas">Horas de Trabalho Economizadas (mês)</Label>
              <Input
                id="horasEconomizadas"
                type="number"
                value={formData.horasEconomizadas}
                onChange={(e) => handleChange('horasEconomizadas', e.target.value)}
                placeholder="0"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <Label htmlFor="economiaCargaTrabalho">Economia com Carga de Trabalho (R$)</Label>
              <Input
                id="economiaCargaTrabalho"
                type="number"
                step="0.01"
                value={formData.economiaCargaTrabalho}
                onChange={(e) => handleChange('economiaCargaTrabalho', e.target.value)}
                placeholder="0.00"
              />
            </div>
            <div>
              <Label htmlFor="economiaProcessos">Economia com Otimização (R$)</Label>
              <Input
                id="economiaProcessos"
                type="number"
                step="0.01"
                value={formData.economiaProcessos}
                onChange={(e) => handleChange('economiaProcessos', e.target.value)}
                placeholder="0.00"
              />
            </div>
            <div>
              <Label htmlFor="aumentoReceita">Aumento de Receita (R$)</Label>
              <Input
                id="aumentoReceita"
                type="number"
                step="0.01"
                value={formData.aumentoReceita}
                onChange={(e) => handleChange('aumentoReceita', e.target.value)}
                placeholder="0.00"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Cálculo do ROI */}
      <Card className="border-2 border-[#00D9A3]">
        <CardHeader className="bg-[#00D9A3]/5">
          <CardTitle>Cálculo do ROI</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4 pt-4">
          <div>
            <Label htmlFor="investimentoInicial">Investimento Inicial (R$)</Label>
            <Input
              id="investimentoInicial"
              type="number"
              step="0.01"
              value={formData.investimentoInicial}
              onChange={(e) => handleChange('investimentoInicial', e.target.value)}
              placeholder="0.00"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
            <Card className="bg-gradient-to-br from-[#00D9A3] to-[#00B88F] text-white">
              <CardContent className="pt-6">
                <p className="text-sm opacity-90 mb-2">ROI Calculado</p>
                <p className="text-4xl font-bold">{calcularROI()}%</p>
              </CardContent>
            </Card>
            <Card className="bg-gradient-to-br from-[#1a1a1a] to-[#333] text-white">
              <CardContent className="pt-6">
                <p className="text-sm opacity-90 mb-2">Payback (meses)</p>
                <p className="text-4xl font-bold">{calcularPayback()}</p>
              </CardContent>
            </Card>
          </div>
        </CardContent>
      </Card>

      {/* Feedback do Cliente */}
      <Card>
        <CardHeader>
          <CardTitle>Feedback do Cliente</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="feedback">Resumo do Feedback</Label>
            <Textarea
              id="feedback"
              value={formData.feedback}
              onChange={(e) => handleChange('feedback', e.target.value)}
              placeholder="Síntese do feedback coletado..."
              rows={3}
            />
          </div>

          <div>
            <Label htmlFor="pontosPositivos">Pontos Positivos</Label>
            <Textarea
              id="pontosPositivos"
              value={formData.pontosPositivos}
              onChange={(e) => handleChange('pontosPositivos', e.target.value)}
              placeholder="Listar os pontos positivos destacados..."
              rows={3}
            />
          </div>

          <div>
            <Label htmlFor="pontosMelhorar">Pontos a Melhorar</Label>
            <Textarea
              id="pontosMelhorar"
              value={formData.pontosMelhorar}
              onChange={(e) => handleChange('pontosMelhorar', e.target.value)}
              placeholder="Listar os pontos que o cliente gostaria de ver melhorados..."
              rows={3}
            />
          </div>
        </CardContent>
      </Card>

      {/* Recomendações */}
      <Card>
        <CardHeader>
          <CardTitle>Recomendações para Otimização e Expansão</CardTitle>
        </CardHeader>
        <CardContent>
          <div>
            <Label htmlFor="recomendacoes">Oportunidades de Melhoria Identificadas</Label>
            <Textarea
              id="recomendacoes"
              value={formData.recomendacoes}
              onChange={(e) => handleChange('recomendacoes', e.target.value)}
              placeholder="Descrever as ações recomendadas para as próximas fases..."
              rows={5}
            />
          </div>
        </CardContent>
      </Card>

      {/* Ações Finais */}
      <Card className="border-2 border-[#00D9A3] bg-[#00D9A3]/5">
        <CardContent className="pt-6">
          <div className="flex items-center gap-3 mb-4">
            <CheckCircle2 className="w-6 h-6 text-[#00D9A3]" />
            <h3 className="text-xl font-semibold">Processo Concluído!</h3>
          </div>
          <p className="text-gray-700 mb-4">
            Todos os dados foram coletados com sucesso. Você pode agora gerar o relatório completo ou voltar para revisar as informações.
          </p>
          <Button 
            type="button" 
            onClick={handleGenerateReport}
            className="w-full bg-gradient-to-r from-[#00D9A3] to-[#00B88F] hover:from-[#00B88F] hover:to-[#00D9A3] text-white"
            size="lg"
          >
            <FileDown className="w-5 h-5 mr-2" />
            Gerar Relatório Completo
          </Button>
        </CardContent>
      </Card>

      <div className="flex justify-between">
        <Button type="button" onClick={onPrevious} variant="outline" size="lg" className="flex items-center gap-2">
          <ArrowLeft className="w-4 h-4" />
          Voltar
        </Button>
      </div>
    </div>
  )
}
