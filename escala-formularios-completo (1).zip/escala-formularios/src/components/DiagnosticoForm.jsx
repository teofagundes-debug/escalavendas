import { useState } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Textarea } from '@/components/ui/textarea.jsx'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx'
import { Checkbox } from '@/components/ui/checkbox.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { ArrowRight, Download, Info } from 'lucide-react'

export default function DiagnosticoForm({ data, onNext, onExport }) {
  const [formData, setFormData] = useState(data)

  const handleChange = (field, value) => {
    setFormData({ ...formData, [field]: value })
  }

  const handleCheckboxChange = (field, value, checked) => {
    const currentValues = formData[field] || []
    if (checked) {
      handleChange(field, [...currentValues, value])
    } else {
      handleChange(field, currentValues.filter(v => v !== value))
    }
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    onNext(formData)
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-8">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-3xl font-bold text-[#00D9A3]">Diagnóstico Inicial</h2>
          <p className="text-gray-600 mt-2">Fase 1: Coleta de Informações</p>
        </div>
        <Button type="button" variant="outline" onClick={onExport} className="flex items-center gap-2">
          <Download className="w-4 h-4" />
          Exportar Dados
        </Button>
      </div>

      <Card className="border-l-4 border-l-[#00D9A3]">
        <CardHeader className="bg-[#00D9A3]/5">
          <CardTitle className="flex items-center gap-2">
            <Info className="w-5 h-5 text-[#00D9A3]" />
            Objetivo
          </CardTitle>
          <CardDescription>
            Este formulário tem como objetivo coletar informações essenciais sobre a operação atual de atendimento e vendas da empresa para elaboração do Parecer de Diagnóstico Inicial.
          </CardDescription>
        </CardHeader>
      </Card>

      {/* Seção 1: Informações Gerais */}
      <Card>
        <CardHeader>
          <CardTitle>1. Informações Gerais</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="nomeEmpresa">Nome da Empresa *</Label>
            <Input
              id="nomeEmpresa"
              value={formData.nomeEmpresa}
              onChange={(e) => handleChange('nomeEmpresa', e.target.value)}
              required
              placeholder="Digite o nome da empresa"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="responsavelAtendimento">Responsável pelo Atendimento *</Label>
              <Input
                id="responsavelAtendimento"
                value={formData.responsavelAtendimento}
                onChange={(e) => handleChange('responsavelAtendimento', e.target.value)}
                required
                placeholder="Nome completo"
              />
            </div>
            <div>
              <Label htmlFor="cargo">Cargo *</Label>
              <Input
                id="cargo"
                value={formData.cargo}
                onChange={(e) => handleChange('cargo', e.target.value)}
                required
                placeholder="Cargo do responsável"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="email">E-mail de Contato *</Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => handleChange('email', e.target.value)}
                required
                placeholder="email@empresa.com"
              />
            </div>
            <div>
              <Label htmlFor="telefone">Telefone *</Label>
              <Input
                id="telefone"
                value={formData.telefone}
                onChange={(e) => handleChange('telefone', e.target.value)}
                required
                placeholder="(00) 00000-0000"
              />
            </div>
          </div>

          <div>
            <Label htmlFor="dataDiagnostico">Data do Diagnóstico *</Label>
            <Input
              id="dataDiagnostico"
              type="date"
              value={formData.dataDiagnostico}
              onChange={(e) => handleChange('dataDiagnostico', e.target.value)}
              required
            />
          </div>
        </CardContent>
      </Card>

      {/* Seção 2: Equipe de Atendimento */}
      <Card>
        <CardHeader>
          <CardTitle>2. Equipe de Atendimento</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="quantidadeAtendentes">Quantidade de Atendentes *</Label>
              <Input
                id="quantidadeAtendentes"
                type="number"
                min="0"
                value={formData.quantidadeAtendentes}
                onChange={(e) => handleChange('quantidadeAtendentes', e.target.value)}
                required
                placeholder="0"
              />
            </div>
            <div>
              <Label htmlFor="turnosAtendimento">Turnos de Atendimento *</Label>
              <Select value={formData.turnosAtendimento} onValueChange={(value) => handleChange('turnosAtendimento', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione..." />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="comercial">Horário Comercial (8h-18h)</SelectItem>
                  <SelectItem value="estendido">Horário Estendido (8h-22h)</SelectItem>
                  <SelectItem value="24x7">24 horas / 7 dias</SelectItem>
                  <SelectItem value="outro">Outro</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div>
            <Label htmlFor="processosAtendimento">Processos Atuais de Atendimento</Label>
            <Textarea
              id="processosAtendimento"
              value={formData.processosAtendimento}
              onChange={(e) => handleChange('processosAtendimento', e.target.value)}
              placeholder="Descreva brevemente como o atendimento é realizado hoje..."
              rows={4}
            />
          </div>
        </CardContent>
      </Card>

      {/* Seção 3: Canais de Atendimento */}
      <Card>
        <CardHeader>
          <CardTitle>3. Canais de Atendimento</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label className="mb-3 block">Canais Utilizados *</Label>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {['WhatsApp', 'Site', 'Instagram', 'Facebook', 'Telefone', 'E-mail', 'Outro'].map((canal) => (
                <div key={canal} className="flex items-center space-x-2">
                  <Checkbox
                    id={canal}
                    checked={formData.canais?.includes(canal)}
                    onCheckedChange={(checked) => handleCheckboxChange('canais', canal, checked)}
                  />
                  <label htmlFor={canal} className="text-sm font-medium cursor-pointer">
                    {canal}
                  </label>
                </div>
              ))}
            </div>
          </div>

          <div>
            <Label htmlFor="volumeAtendimentos">Volume Médio de Atendimentos por Mês *</Label>
            <Input
              id="volumeAtendimentos"
              type="number"
              min="0"
              value={formData.volumeAtendimentos}
              onChange={(e) => handleChange('volumeAtendimentos', e.target.value)}
              required
              placeholder="0"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="tempoMedioAtendimento">Tempo Médio de Atendimento (minutos)</Label>
              <Input
                id="tempoMedioAtendimento"
                type="number"
                min="0"
                value={formData.tempoMedioAtendimento}
                onChange={(e) => handleChange('tempoMedioAtendimento', e.target.value)}
                placeholder="0"
              />
            </div>
            <div>
              <Label htmlFor="tempoPrimeiraResposta">Tempo Médio de Primeira Resposta (minutos)</Label>
              <Input
                id="tempoPrimeiraResposta"
                type="number"
                min="0"
                value={formData.tempoPrimeiraResposta}
                onChange={(e) => handleChange('tempoPrimeiraResposta', e.target.value)}
                placeholder="0"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Seção 4: Custos */}
      <Card>
        <CardHeader>
          <CardTitle>4. Custos Envolvidos</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="custoFolha">Custo Mensal com Folha de Pagamento (R$)</Label>
            <Input
              id="custoFolha"
              type="number"
              min="0"
              step="0.01"
              value={formData.custoFolha}
              onChange={(e) => handleChange('custoFolha', e.target.value)}
              placeholder="0.00"
            />
          </div>

          <div>
            <Label htmlFor="custoFerramentas">Custo Mensal com Ferramentas e Sistemas (R$)</Label>
            <Input
              id="custoFerramentas"
              type="number"
              min="0"
              step="0.01"
              value={formData.custoFerramentas}
              onChange={(e) => handleChange('custoFerramentas', e.target.value)}
              placeholder="0.00"
            />
          </div>

          <div>
            <Label htmlFor="custoPerdas">Estimativa de Perdas por Atendimento Ineficiente (R$)</Label>
            <Input
              id="custoPerdas"
              type="number"
              min="0"
              step="0.01"
              value={formData.custoPerdas}
              onChange={(e) => handleChange('custoPerdas', e.target.value)}
              placeholder="0.00"
            />
          </div>
        </CardContent>
      </Card>

      {/* Seção 5: Objetivos */}
      <Card>
        <CardHeader>
          <CardTitle>5. Objetivos e Metas</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="objetivoPrincipal">Objetivo Principal com a Solução de IA *</Label>
            <Select value={formData.objetivoPrincipal} onValueChange={(value) => handleChange('objetivoPrincipal', value)}>
              <SelectTrigger>
                <SelectValue placeholder="Selecione..." />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="reduzir-custos">Reduzir custos operacionais</SelectItem>
                <SelectItem value="aumentar-vendas">Aumentar vendas</SelectItem>
                <SelectItem value="agilizar-resposta">Agilizar tempo de resposta</SelectItem>
                <SelectItem value="melhorar-satisfacao">Melhorar satisfação do cliente</SelectItem>
                <SelectItem value="escalar-atendimento">Escalar o atendimento</SelectItem>
                <SelectItem value="outro">Outro</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="metasQuantitativas">Metas Quantitativas</Label>
            <Textarea
              id="metasQuantitativas"
              value={formData.metasQuantitativas}
              onChange={(e) => handleChange('metasQuantitativas', e.target.value)}
              placeholder="Ex: Reduzir TMA em 40%, aumentar vendas em 25%, reduzir custos em 30%"
              rows={3}
            />
          </div>
        </CardContent>
      </Card>

      {/* Seção 6: Desafios */}
      <Card>
        <CardHeader>
          <CardTitle>6. Principais Desafios</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="desafios">Principais Desafios Enfrentados *</Label>
            <Textarea
              id="desafios"
              value={formData.desafios}
              onChange={(e) => handleChange('desafios', e.target.value)}
              required
              placeholder="Descreva os principais gargalos e desafios no atendimento atual"
              rows={4}
            />
          </div>

          <div>
            <Label htmlFor="pontosAtrito">Pontos de Atrito Identificados</Label>
            <Textarea
              id="pontosAtrito"
              value={formData.pontosAtrito}
              onChange={(e) => handleChange('pontosAtrito', e.target.value)}
              placeholder="Anotar percepções preliminares sobre pontos de atrito na operação"
              rows={4}
            />
          </div>
        </CardContent>
      </Card>

      {/* Seção 7: Informações Adicionais */}
      <Card>
        <CardHeader>
          <CardTitle>7. Informações Adicionais</CardTitle>
        </CardHeader>
        <CardContent>
          <div>
            <Label htmlFor="observacoes">Observações ou Informações Complementares</Label>
            <Textarea
              id="observacoes"
              value={formData.observacoes}
              onChange={(e) => handleChange('observacoes', e.target.value)}
              placeholder="Qualquer informação adicional que considere relevante"
              rows={4}
            />
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-end">
        <Button type="submit" size="lg" className="bg-[#00D9A3] hover:bg-[#00B88F] text-white flex items-center gap-2">
          Próximo: Matriz de ROI
          <ArrowRight className="w-4 h-4" />
        </Button>
      </div>
    </form>
  )
}
