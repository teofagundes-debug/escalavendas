import { useState } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Textarea } from '@/components/ui/textarea.jsx'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { ArrowRight, ArrowLeft, Download, Plus, Trash2 } from 'lucide-react'

export default function MatrizROI({ data, onNext, onPrevious, onExport }) {
  const [formData, setFormData] = useState({
    ...data,
    oportunidades: data.oportunidades?.length > 0 ? data.oportunidades : [
      { nome: '', descricao: '', metrica: '', cenarioAtual: '', cenarioPosIA: '', ganho: '', potencial: 'medio' }
    ]
  })

  const handleChange = (field, value) => {
    setFormData({ ...formData, [field]: value })
  }

  const handleOportunidadeChange = (index, field, value) => {
    const newOportunidades = [...formData.oportunidades]
    newOportunidades[index][field] = value
    handleChange('oportunidades', newOportunidades)
  }

  const addOportunidade = () => {
    handleChange('oportunidades', [
      ...formData.oportunidades,
      { nome: '', descricao: '', metrica: '', cenarioAtual: '', cenarioPosIA: '', ganho: '', potencial: 'medio' }
    ])
  }

  const removeOportunidade = (index) => {
    const newOportunidades = formData.oportunidades.filter((_, i) => i !== index)
    handleChange('oportunidades', newOportunidades)
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    onNext(formData)
  }

  const getPotencialBadge = (potencial) => {
    const variants = {
      alto: 'bg-[#00D9A3] text-white',
      medio: 'bg-yellow-500 text-white',
      baixo: 'bg-gray-500 text-white'
    }
    return variants[potencial] || variants.medio
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-8">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-3xl font-bold text-[#00D9A3]">Matriz de Potencial de ROI</h2>
          <p className="text-gray-600 mt-2">Fase 2: Análise de Oportunidades</p>
        </div>
        <Button type="button" variant="outline" onClick={onExport} className="flex items-center gap-2">
          <Download className="w-4 h-4" />
          Exportar Dados
        </Button>
      </div>

      {/* Informações Automáticas */}
      <Card className="border-l-4 border-l-[#00D9A3] bg-[#00D9A3]/5">
        <CardHeader>
          <CardTitle>Informações do Cliente</CardTitle>
          <CardDescription>Dados coletados no diagnóstico inicial</CardDescription>
        </CardHeader>
        <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <p className="text-sm font-medium text-gray-600">Empresa</p>
            <p className="text-lg font-semibold">{data.nomeEmpresa || 'Não informado'}</p>
          </div>
          <div>
            <p className="text-sm font-medium text-gray-600">Responsável</p>
            <p className="text-lg font-semibold">{data.responsavelAtendimento || 'Não informado'}</p>
          </div>
          <div>
            <p className="text-sm font-medium text-gray-600">Data do Diagnóstico</p>
            <p className="text-lg font-semibold">
              {data.dataDiagnostico ? new Date(data.dataDiagnostico).toLocaleDateString('pt-BR') : 'Não informado'}
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Cenário Atual */}
      <Card>
        <CardHeader>
          <CardTitle>Cenário Atual e Oportunidades</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="pontosAtritoMatriz">Principais Pontos de Atrito</Label>
            <Textarea
              id="pontosAtritoMatriz"
              value={formData.pontosAtritoMatriz || data.pontosAtrito}
              onChange={(e) => handleChange('pontosAtritoMatriz', e.target.value)}
              placeholder="Listar os problemas identificados que geram custos ou ineficiência..."
              rows={4}
            />
          </div>

          <div>
            <Label htmlFor="oportunidadesGanho">Principais Oportunidades de Ganho</Label>
            <Textarea
              id="oportunidadesGanho"
              value={formData.oportunidadesGanho}
              onChange={(e) => handleChange('oportunidadesGanho', e.target.value)}
              placeholder="Listar as áreas onde a solução de IA pode gerar valor..."
              rows={4}
            />
          </div>
        </CardContent>
      </Card>

      {/* Matriz de Oportunidades */}
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle>Matriz de Oportunidades de ROI</CardTitle>
              <CardDescription>Detalhe cada oportunidade identificada</CardDescription>
            </div>
            <Button type="button" onClick={addOportunidade} variant="outline" size="sm" className="flex items-center gap-2">
              <Plus className="w-4 h-4" />
              Adicionar Oportunidade
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          {formData.oportunidades.map((oportunidade, index) => (
            <Card key={index} className="border-2">
              <CardHeader className="bg-gray-50">
                <div className="flex justify-between items-center">
                  <CardTitle className="text-lg">Oportunidade {index + 1}</CardTitle>
                  {formData.oportunidades.length > 1 && (
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => removeOportunidade(index)}
                      className="text-red-500 hover:text-red-700 hover:bg-red-50"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  )}
                </div>
              </CardHeader>
              <CardContent className="space-y-4 pt-4">
                <div>
                  <Label>Nome da Oportunidade</Label>
                  <Input
                    value={oportunidade.nome}
                    onChange={(e) => handleOportunidadeChange(index, 'nome', e.target.value)}
                    placeholder="Ex: Redução de TMA"
                  />
                </div>

                <div>
                  <Label>Descrição Detalhada</Label>
                  <Textarea
                    value={oportunidade.descricao}
                    onChange={(e) => handleOportunidadeChange(index, 'descricao', e.target.value)}
                    placeholder="Descreva como essa oportunidade pode gerar valor..."
                    rows={3}
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label>Métrica Chave</Label>
                    <Input
                      value={oportunidade.metrica}
                      onChange={(e) => handleOportunidadeChange(index, 'metrica', e.target.value)}
                      placeholder="Ex: Tempo Médio de Atendimento"
                    />
                  </div>
                  <div>
                    <Label>Potencial de ROI</Label>
                    <Select
                      value={oportunidade.potencial}
                      onValueChange={(value) => handleOportunidadeChange(index, 'potencial', value)}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="alto">Alto</SelectItem>
                        <SelectItem value="medio">Médio</SelectItem>
                        <SelectItem value="baixo">Baixo</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <Label>Cenário Atual</Label>
                    <Input
                      value={oportunidade.cenarioAtual}
                      onChange={(e) => handleOportunidadeChange(index, 'cenarioAtual', e.target.value)}
                      placeholder="Ex: 15 minutos"
                    />
                  </div>
                  <div>
                    <Label>Cenário Pós-IA</Label>
                    <Input
                      value={oportunidade.cenarioPosIA}
                      onChange={(e) => handleOportunidadeChange(index, 'cenarioPosIA', e.target.value)}
                      placeholder="Ex: 8 minutos"
                    />
                  </div>
                  <div>
                    <Label>Ganho Estimado</Label>
                    <Input
                      value={oportunidade.ganho}
                      onChange={(e) => handleOportunidadeChange(index, 'ganho', e.target.value)}
                      placeholder="Ex: 47% / R$ 5.000"
                    />
                  </div>
                </div>

                <div className="flex justify-end">
                  <Badge className={getPotencialBadge(oportunidade.potencial)}>
                    Potencial: {oportunidade.potencial.charAt(0).toUpperCase() + oportunidade.potencial.slice(1)}
                  </Badge>
                </div>
              </CardContent>
            </Card>
          ))}
        </CardContent>
      </Card>

      {/* Estimativa de ROI */}
      <Card>
        <CardHeader>
          <CardTitle>Estimativa de Retorno Financeiro</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="reducaoCustos">Estimativa de Redução de Custos Mensal (R$)</Label>
              <Input
                id="reducaoCustos"
                type="number"
                step="0.01"
                value={formData.reducaoCustos}
                onChange={(e) => handleChange('reducaoCustos', e.target.value)}
                placeholder="0.00"
              />
            </div>
            <div>
              <Label htmlFor="aumentoReceita">Estimativa de Aumento de Receita Mensal (R$)</Label>
              <Input
                id="aumentoReceita"
                type="number"
                step="0.01"
                value={formData.aumentoReceita}
                onChange={(e) => handleChange('aumentoReceita', e.target.value)}
                placeholder="0.00"
              />
            </div>
          </div>

          <div>
            <Label htmlFor="roiProjetado">ROI Projetado (Primeiros 3-6 meses) (%)</Label>
            <Input
              id="roiProjetado"
              type="number"
              step="0.01"
              value={formData.roiProjetado}
              onChange={(e) => handleChange('roiProjetado', e.target.value)}
              placeholder="0"
            />
          </div>
        </CardContent>
      </Card>

      {/* Considerações */}
      <Card>
        <CardHeader>
          <CardTitle>Considerações e Próximos Passos</CardTitle>
        </CardHeader>
        <CardContent>
          <div>
            <Label htmlFor="consideracoes">Premissas e Observações</Label>
            <Textarea
              id="consideracoes"
              value={formData.consideracoes}
              onChange={(e) => handleChange('consideracoes', e.target.value)}
              placeholder="Adicione observações sobre as premissas utilizadas na análise..."
              rows={4}
            />
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-between">
        <Button type="button" onClick={onPrevious} variant="outline" size="lg" className="flex items-center gap-2">
          <ArrowLeft className="w-4 h-4" />
          Voltar
        </Button>
        <Button type="submit" size="lg" className="bg-[#00D9A3] hover:bg-[#00B88F] text-white flex items-center gap-2">
          Próximo: Relatório de ROI
          <ArrowRight className="w-4 h-4" />
        </Button>
      </div>
    </form>
  )
}
