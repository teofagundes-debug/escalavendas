# Guia Rápido - Sistema de Diagnóstico Escala Vendas

## 🚀 Início Rápido

### Passo 1: Descompactar o arquivo
Extraia o arquivo `escala-formularios-completo.zip` em uma pasta de sua preferência.

### Passo 2: Instalar dependências
Abra o terminal na pasta extraída e execute:
```bash
cd escala-formularios
pnpm install
```
*Se não tiver o pnpm instalado, use `npm install` ou `yarn install`*

### Passo 3: Executar localmente
```bash
pnpm run dev
```
Acesse no navegador: `http://localhost:5173`

### Passo 4: Build para produção
```bash
pnpm run build
```
Os arquivos prontos para hospedagem estarão na pasta `dist/`

## 📤 Como Hospedar

### Opção Mais Fácil: Vercel
1. Acesse [vercel.com](https://vercel.com) e crie uma conta gratuita
2. Clique em "Add New Project"
3. Arraste a pasta `escala-formularios` ou conecte seu repositório Git
4. Clique em "Deploy"
5. Pronto! Sua aplicação estará online em segundos

### Opção Alternativa: Netlify
1. Acesse [netlify.com](https://netlify.com) e crie uma conta gratuita
2. Faça o build: `pnpm run build`
3. Arraste a pasta `dist/` para o Netlify Drop
4. Sua aplicação estará online!

## 💡 Como Funciona

### Fluxo de Trabalho
1. **Diagnóstico Inicial** - Preencha os dados da empresa e operação atual
2. **Matriz de ROI** - Os dados são automaticamente carregados, adicione as oportunidades
3. **Relatório de ROI** - Compare antes/depois e veja os cálculos automáticos

### Recursos Principais
- ✅ **Preenchimento automático** entre fases
- ✅ **Exportação de dados** em cada fase
- ✅ **Cálculos automáticos** de ROI e Payback
- ✅ **Design profissional** com cores da Escala Vendas
- ✅ **Responsivo** - funciona em desktop, tablet e celular

## 🎨 Personalização

### Alterar Cores
Edite o arquivo `src/App.css` e modifique as variáveis:
```css
--primary: oklch(0.72 0.15 172);  /* Verde Escala Vendas */
--secondary: oklch(0.145 0 0);     /* Preto */
```

### Adicionar Campos
Edite os componentes em `src/components/`:
- `DiagnosticoForm.jsx` - Fase 1
- `MatrizROI.jsx` - Fase 2
- `RelatorioROI.jsx` - Fase 3

## 📊 Exportação de Dados

### Durante o Processo
Clique em "Exportar Dados" em cada fase para salvar um backup JSON.

### Relatório Final
Na última fase, clique em "Gerar Relatório Completo" para exportar todos os dados incluindo:
- Todos os dados coletados
- ROI calculado
- Payback calculado
- Variações percentuais

## 🔧 Solução de Problemas

### Erro ao instalar dependências
```bash
# Limpe o cache e reinstale
rm -rf node_modules pnpm-lock.yaml
pnpm install
```

### Porta 5173 já em uso
```bash
# Use outra porta
pnpm run dev -- --port 3000
```

### Build não funciona
```bash
# Verifique se todas as dependências estão instaladas
pnpm install
pnpm run build
```

## 📞 Suporte

**Escala Vendas**
- E-mail: contato@escalavendas.com.br
- Endereço: R. Marechal Deodoro 450, Sala 304, Centro - Curitiba/PR

---

**Desenvolvido com ❤️ para Escala Vendas**
